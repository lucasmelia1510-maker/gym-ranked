import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  createUserWithEmailAndPassword, onAuthStateChanged, signInWithEmailAndPassword, signOut,
  updateProfile
} from 'firebase/auth';
import {
  collection, doc, getDoc, onSnapshot, runTransaction, serverTimestamp, setDoc, addDoc,
  query, orderBy, limit
} from 'firebase/firestore';
import { auth, db, firebaseConfigured } from './firebase';
import { Activity, ArrowLeft, ArrowRight, Award, CalendarCheck, CheckCircle2, ChevronRight, Dumbbell, LogOut, Shield, Trophy, Users, Zap } from 'lucide-react';
import './style.css';

const PUSH = [
  'Incline Dumbbell Bench Press', 'Pec Deck', 'Shoulder Press',
  'Lateral Raise Machine', 'Triceps Extensions', 'Triceps Pulldowns'
];
const PULL = [
  'T-Bar Row', 'Close-Grip Seated Row', 'Preacher Curls',
  'Hammer Curls / Bayesian Curls (alternate each Pull day)', 'Seated Shrugs', 'Seated Crunches'
];
const RANKS = [
  ['IRON', 0, 600], ['BRONZE', 600, 1500], ['SILVER', 1500, 2700], ['GOLD', 2700, 4200],
  ['PLATINUM', 4200, 6200], ['DIAMOND', 6200, 8700], ['ELITE', 8700, 12000], ['CHAMPION', 12000, Infinity]
];
const rankFor = xp => RANKS.find(([_, min, max]) => xp >= min && xp < max)?.[0] || 'CHAMPION';
const levelFor = xp => Math.floor(xp / 100) + 1;
const rankMin = rank => RANKS.find(([name]) => name === rank)?.[1] ?? 0;
const rankMax = rank => RANKS.find(([name]) => name === rank)?.[2] ?? Infinity;
const weekKey = () => {
  const d = new Date();
  const day = (d.getDay() + 6) % 7;
  d.setDate(d.getDate() - day); d.setHours(0, 0, 0, 0);
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
};
const blankLogs = type => (type === 'Push' ? PUSH : PULL).map(name => ({ name, sets: Array.from({ length: 3 }, () => ({ weight: '', reps: '' })) }));
const safeMessage = e => e?.message?.replace('Firebase: ', '') || 'Something went wrong. Please try again.';

function App() {
  const [user, setUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [mode, setMode] = useState('register');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [roomCode, setRoomCode] = useState('');
  const [profile, setProfile] = useState(null);
  const [members, setMembers] = useState([]);
  const [tab, setTab] = useState('home');
  const [workoutType, setWorkoutType] = useState('Pull');
  const [logs, setLogs] = useState(blankLogs('Pull'));
  const [pb, setPb] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [history, setHistory] = useState([]);

  useEffect(() => {
    if (!auth) { setAuthLoading(false); return; }
    return onAuthStateChanged(auth, async u => {
      setUser(u); setAuthLoading(false); setError('');
      if (u) {
        try {
          const p = await getDoc(doc(db, 'profiles', u.uid));
          if (p.exists()) setDisplayName(p.data().displayName || u.displayName || 'Player');
        } catch (e) { setError(safeMessage(e)); }
      } else { setProfile(null); setMembers([]); }
    });
  }, []);

  useEffect(() => {
    if (!user || !db) return;
    return onSnapshot(doc(db, 'profiles', user.uid), snap => {
      if (snap.exists()) setProfile(snap.data()); else setProfile(null);
    }, e => setError(safeMessage(e)));
  }, [user]);

  useEffect(() => {
    if (!user || !profile?.roomId || !db) { setMembers([]); return; }
    const unsubMembers = onSnapshot(collection(db, 'rooms', profile.roomId, 'members'), snap => {
      setMembers(snap.docs.map(d => ({ uid: d.id, ...d.data() })).sort((a,b) => (b.xp || 0) - (a.xp || 0)));
    }, e => setError(safeMessage(e)));
    const q = query(collection(db, 'rooms', profile.roomId, 'sessions'), orderBy('completedAt', 'desc'), limit(10));
    const unsubHistory = onSnapshot(q, snap => setHistory(snap.docs.map(d => ({ id: d.id, ...d.data() }))), e => setError(safeMessage(e)));
    return () => { unsubMembers(); unsubHistory(); };
  }, [user, profile?.roomId]);

  const me = members.find(m => m.uid === user?.uid) || (profile && user ? { uid: user.uid, ...profile } : null);
  const opponent = members.find(m => m.uid !== user?.uid);
  const rank = rankFor(me?.xp || 0);
  const level = levelFor(me?.xp || 0);
  const rankProgress = rank === 'CHAMPION' ? 1 : Math.max(0, Math.min(1, ((me?.xp || 0) - rankMin(rank)) / (rankMax(rank) - rankMin(rank))));

  async function handleAuth(e) {
    e.preventDefault(); setError(''); setBusy(true);
    try {
      if (mode === 'register') {
        if (password.length < 6) throw new Error('Use a password with at least 6 characters.');
        const result = await createUserWithEmailAndPassword(auth, email.trim(), password);
        const name = displayName.trim() || email.split('@')[0] || 'Player';
        await updateProfile(result.user, { displayName: name });
        await setDoc(doc(db, 'profiles', result.user.uid), { uid: result.user.uid, displayName: name, xp: 0, workouts: 0, personalBests: 0, weeklyWorkouts: 0, weekKey: weekKey(), roomId: '', createdAt: serverTimestamp() });
        setNotice('Account created. Now create a room or join your partner.');
      } else await signInWithEmailAndPassword(auth, email.trim(), password);
    } catch (e) { setError(safeMessage(e)); }
    finally { setBusy(false); }
  }

  async function createRoom() {
    setBusy(true); setError('');
    try {
      const code = Math.random().toString(36).slice(2, 8).toUpperCase();
      const pRef = doc(db, 'profiles', user.uid);
      const roomRef = doc(db, 'rooms', code);
      const memberRef = doc(db, 'rooms', code, 'members', user.uid);
      const name = displayName.trim() || user.displayName || user.email?.split('@')[0] || 'Player';
      await runTransaction(db, async tx => {
        const ps = await tx.get(pRef);
        if (!ps.exists()) throw new Error('Player profile is missing. Sign out and sign back in.');
        tx.set(roomRef, { code, createdBy: user.uid, createdAt: serverTimestamp() });
        tx.set(memberRef, { uid: user.uid, displayName: name, xp: 0, workouts: 0, personalBests: 0, weeklyWorkouts: 0, weekKey: weekKey(), createdAt: serverTimestamp() });
        tx.update(pRef, { displayName: name, roomId: code });
      });
      setRoomCode(code); setNotice(`Room created. Share code ${code} with your partner.`);
    } catch (e) { setError(safeMessage(e)); }
    finally { setBusy(false); }
  }

  async function joinRoom() {
    setBusy(true); setError('');
    try {
      const code = roomCode.trim().toUpperCase();
      if (!code) throw new Error('Enter the room code from Player 1.');
      const roomRef = doc(db, 'rooms', code);
      const roomSnap = await getDoc(roomRef);
      if (!roomSnap.exists()) throw new Error('Room not found. Check the code.');
      const membersSnap = await getDoc(doc(db, 'rooms', code, 'members', user.uid));
      if (!membersSnap.exists()) {
        // Firestore rules and membership constraints should be configured before live use.
        const name = displayName.trim() || user.displayName || user.email?.split('@')[0] || 'Player';
        await setDoc(doc(db, 'rooms', code, 'members', user.uid), { uid: user.uid, displayName: name, xp: 0, workouts: 0, personalBests: 0, weeklyWorkouts: 0, weekKey: weekKey(), createdAt: serverTimestamp() });
        await setDoc(doc(db, 'profiles', user.uid), { uid: user.uid, displayName: name, roomId: code }, { merge: true });
      } else await setDoc(doc(db, 'profiles', user.uid), { roomId: code }, { merge: true });
      setNotice(`Joined room ${code}.`);
    } catch (e) { setError(safeMessage(e)); }
    finally { setBusy(false); }
  }

  function startWorkout(type) { setWorkoutType(type); setLogs(blankLogs(type)); setPb(false); setError(''); setNotice(''); setTab('workout'); }
  function editSet(exIndex, setIndex, field, value) {
    setLogs(old => old.map((log, i) => i !== exIndex ? log : ({ ...log, sets: log.sets.map((s, j) => j !== setIndex ? s : ({ ...s, [field]: value })) })));
  }

  async function finishWorkout() {
    setBusy(true); setError('');
    try {
      const room = profile?.roomId;
      if (!room || !user) throw new Error('Your room is not ready.');
      const memberRef = doc(db, 'rooms', room, 'members', user.uid);
      const profileRef = doc(db, 'profiles', user.uid);
      const sessionRef = doc(collection(db, 'rooms', room, 'sessions'));
      const validExercises = logs.filter(log => log.sets.every(s => s.weight.trim() !== '' && s.reps.trim() !== ''));
      const allExercises = logs.length === 6 && validExercises.length === 6;
      const nowWeek = weekKey();
      let award = 0;
      await runTransaction(db, async tx => {
        const snap = await tx.get(memberRef);
        if (!snap.exists()) throw new Error('Player membership was not found. Rejoin your room.');
        const old = snap.data();
        const sameWeek = old.weekKey === nowWeek;
        const oldWeekly = sameWeek ? Number(old.weeklyWorkouts || 0) : 0;
        const newWeekly = oldWeekly + 1;
        const weeklyBonus = oldWeekly < 4 && newWeekly >= 4 ? 100 : 0;
        award = 100 + (allExercises ? 25 : 0) + (pb ? 50 : 0) + weeklyBonus;
        const newXp = Number(old.xp || 0) + award;
        const newPbs = Number(old.personalBests || 0) + (pb ? 1 : 0);
        tx.update(memberRef, { xp: newXp, workouts: Number(old.workouts || 0) + 1, personalBests: newPbs, weeklyWorkouts: Math.min(newWeekly, 4), weekKey: nowWeek, lastWorkoutAt: serverTimestamp() });
        tx.set(profileRef, { xp: newXp, workouts: Number(old.workouts || 0) + 1, personalBests: newPbs, weeklyWorkouts: Math.min(newWeekly, 4), weekKey: nowWeek, lastWorkoutAt: serverTimestamp() }, { merge: true });
        tx.set(sessionRef, { uid: user.uid, displayName: me?.displayName || user.displayName || 'Player', workoutType, sets: logs.map(log => ({ exercise: log.name, sets: log.sets.map(s => ({ weight: s.weight, reps: s.reps })) })), xpEarned: award, newPB: pb, completedExercises: validExercises.length, completedAt: serverTimestamp() });
      });
      setNotice(`Workout complete! +${award} XP${pb ? ' · Personal best bonus included' : ''}.`);
      setTab('home'); setLogs(blankLogs(workoutType)); setPb(false);
    } catch (e) { setError(safeMessage(e)); }
    finally { setBusy(false); }
  }

  if (!firebaseConfigured) return <SetupNotice />;
  if (authLoading) return <div className="screen-center"><div className="spinner"/><p>Loading Gym Ranked…</p></div>;
  if (!user) return <AuthScreen {...{ mode, setMode, email, setEmail, password, setPassword, displayName, setDisplayName, handleAuth, busy, error }} />;
  if (!profile || !profile.roomId) return <LobbyScreen {...{ user, displayName, setDisplayName, roomCode, setRoomCode, createRoom, joinRoom, busy, error, notice, signOut: () => signOut(auth) }} />;

  return <main className="app-shell">
    <header className="topbar">
      <div className="brand"><div className="brand-mark"><Dumbbell size={24}/></div><div><div className="brand-name">GYM RANKED</div><div className="brand-sub">SEASON 01 · ROOM {profile.roomId}</div></div></div>
      <div className="top-actions"><button className="icon-button" onClick={() => setTab('leaderboard')} title="Leaderboard"><Trophy size={19}/></button><button className="icon-button" onClick={() => signOut(auth)} title="Sign out"><LogOut size={18}/></button></div>
    </header>
    {error && <div className="alert error">{error}<button onClick={() => setError('')}>×</button></div>}
    {notice && <div className="alert success">{notice}<button onClick={() => setNotice('')}>×</button></div>}
    {tab === 'workout' ? <WorkoutScreen {...{ workoutType, logs, editSet, pb, setPb, finishWorkout, busy, onBack: () => setTab('home') }} /> :
      tab === 'leaderboard' ? <Leaderboard members={members} uid={user.uid} onBack={() => setTab('home')} /> :
      tab === 'stats' ? <StatsScreen {...{ me, history, onBack: () => setTab('home') }} /> :
      <HomeScreen {...{ me, rank, level, rankProgress, members, opponent, onPush: () => startWorkout('Push'), onPull: () => startWorkout('Pull'), onLeaderboard: () => setTab('leaderboard'), onStats: () => setTab('stats'), history }} />}
    <footer className="footer">TRAIN SMART · TRACK YOUR PROGRESS · LEVEL UP</footer>
  </main>;
}

function SetupNotice() {
  return <main className="setup-page"><div className="brand-mark big"><Dumbbell size={30}/></div><p className="eyebrow">MULTIPLAYER TRAINING LEAGUE</p><h1>GYM <span>RANKED</span></h1><section className="panel setup-panel"><h2>Connect Firebase to launch</h2><p>The website source is ready, but Firebase credentials have not been added yet. Follow the README to create your Firebase project and set the Vercel environment variables.</p><ol><li>Create a Firebase project and web app.</li><li>Enable Email/Password Authentication and Firestore.</li><li>Add the six <code>VITE_FIREBASE_…</code> variables in Vercel.</li><li>Deploy Firestore security rules before inviting another player.</li></ol><p className="muted">This screen is expected until the app is configured. Nothing has been deployed from this source package.</p></section></main>;
}

function AuthScreen({ mode, setMode, email, setEmail, password, setPassword, displayName, setDisplayName, handleAuth, busy, error }) {
  return <main className="auth-page"><div className="auth-card panel"><div className="brand-mark big"><Dumbbell size={30}/></div><p className="eyebrow">TWO-PLAYER TRAINING LEAGUE</p><h1>GYM <span>RANKED</span></h1><p className="muted">Your training. Your rank. Your rivalry.</p><form onSubmit={handleAuth}>
    {mode === 'register' && <label>Player name<input value={displayName} onChange={e => setDisplayName(e.target.value)} placeholder="Your display name" maxLength={24}/></label>}
    <label>Email<input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" required autoComplete="email"/></label>
    <label>Password<input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 6 characters" required minLength={6} autoComplete={mode === 'register' ? 'new-password' : 'current-password'}/></label>
    {error && <div className="alert error">{error}</div>}
    <button className="primary full" disabled={busy}>{busy ? 'PLEASE WAIT…' : mode === 'register' ? 'CREATE ACCOUNT' : 'SIGN IN'} <ArrowRight size={17}/></button>
  </form><button className="text-button" onClick={() => setMode(mode === 'register' ? 'login' : 'register')}>{mode === 'register' ? 'Already have an account? Sign in' : 'New player? Create an account'}</button><p className="tiny muted">Use a separate account for each player. Never share your password.</p></div></main>;
}

function LobbyScreen({ user, displayName, setDisplayName, roomCode, setRoomCode, createRoom, joinRoom, busy, error, notice, signOut }) {
  return <main className="lobby-page"><header className="topbar"><div className="brand"><div className="brand-mark"><Dumbbell size={23}/></div><div><div className="brand-name">GYM RANKED</div><div className="brand-sub">PLAYER LOBBY</div></div></div><button className="icon-button" onClick={signOut}><LogOut size={18}/></button></header><section className="panel lobby-card"><p className="eyebrow">WELCOME TO THE LEAGUE</p><h1>Build your <span>profile.</span></h1><p className="muted">Create a private room and share its code with your opponent, or enter the code they gave you.</p><label>Player name<input value={displayName} onChange={e => setDisplayName(e.target.value)} placeholder={user.displayName || 'Player name'} maxLength={24}/></label><div className="divider"/><label>Room code<input value={roomCode} onChange={e => setRoomCode(e.target.value.toUpperCase())} placeholder="e.g. A1B2C3" maxLength={12}/></label>{error && <div className="alert error">{error}</div>}{notice && <div className="alert success">{notice}</div>}<button className="primary full" onClick={createRoom} disabled={busy}>{busy ? 'PLEASE WAIT…' : 'CREATE NEW ROOM'} <ArrowRight size={17}/></button><button className="secondary full" onClick={joinRoom} disabled={busy || !roomCode.trim()}>JOIN ROOM</button><p className="tiny muted">Share only the room code with your chosen training partner.</p></section></main>;
}

function HomeScreen({ me, rank, level, rankProgress, members, opponent, onPush, onPull, onLeaderboard, onStats, history }) {
  const xp = me?.xp || 0;
  const week = me?.weekKey === weekKey() ? (me?.weeklyWorkouts || 0) : 0;
  const max = rankMax(rank);
  const nextText = rank === 'CHAMPION' ? 'MAX RANK REACHED' : `${max - xp} XP TO ${RANKS.find(r => r[1] === max)?.[0] || 'NEXT RANK'}`;
  return <>
    <section className="hero panel"><div className="rank-emblem"><Shield size={36}/><b>{rank === 'CHAMPION' ? 'C' : rank[0]}</b></div><div className="rank-info"><p className="eyebrow">CURRENT RANK</p><h1>{rank} <span>{rank === 'CHAMPION' ? '' : rank === 'IRON' ? 'I' : 'I'}</span></h1><p className="muted">Level {level} · {me?.displayName || 'Player'}</p><div className="progress-track"><div className="progress-fill" style={{ width: `${rankProgress * 100}%` }}/></div><div className="progress-caption"><span>{xp.toLocaleString()} XP</span><span>{nextText}</span></div></div></section>
    <section className="stat-grid"><Stat icon={<Zap/>} label="TOTAL XP" value={xp.toLocaleString()}/><Stat icon={<CalendarCheck/>} label="WORKOUTS" value={me?.workouts || 0}/><Stat icon={<Trophy/>} label="PERSONAL BESTS" value={me?.personalBests || 0}/><Stat icon={<Activity/>} label="WEEKLY TARGET" value={`${week}/4`}/></section>
    <section className="section-heading"><div><p className="eyebrow">YOUR TRAINING PLAN</p><h2>Select your workout</h2></div><span className="tag">PUSH / PULL</span></section>
    <section className="workout-select"><button className="workout-card" onClick={onPush}><span className="workout-icon"><Dumbbell/></span><span className="workout-title">PUSH</span><span className="muted">Chest · Shoulders · Triceps</span><span className="workout-count">6 exercises · 18 sets <ChevronRight size={16}/></span></button><button className="workout-card" onClick={onPull}><span className="workout-icon"><Dumbbell/></span><span className="workout-title">PULL</span><span className="muted">Back · Biceps · Traps · Abs</span><span className="workout-count">6 exercises · 18 sets <ChevronRight size={16}/></span></button></section>
    <section className="panel leaderboard-preview"><div className="panel-heading"><div><p className="eyebrow">THE RIVALRY</p><h2>Two-player leaderboard</h2></div><button className="icon-button" onClick={onLeaderboard}><ArrowRight size={18}/></button></div>{members.length ? members.slice(0,2).map((p,i)=><div className="player-row" key={p.uid}><div className="place">{i+1}</div><div className="player-avatar">{(p.displayName || 'P').slice(0,1).toUpperCase()}</div><div className="player-name">{p.displayName || 'Player'}{p.uid === me?.uid && <small>YOU</small>}<small>{rankFor(p.xp || 0)} · LEVEL {levelFor(p.xp || 0)}</small></div><strong>{(p.xp || 0).toLocaleString()} <small>XP</small></strong></div>) : <p className="muted">Waiting for your partner to join… Share your room code.</p>}{!opponent && <p className="tiny muted">Invite one player to unlock head-to-head comparison.</p>}<button className="secondary full" onClick={onLeaderboard}>VIEW LEADERBOARD</button></section>
    <section className="panel recent-panel"><div className="panel-heading"><div><p className="eyebrow">LATEST ACTIVITY</p><h2>Recent sessions</h2></div><button className="text-button" onClick={onStats}>All stats <ArrowRight size={14}/></button></div>{history.slice(0,3).length ? history.slice(0,3).map(s=><div className="history-row" key={s.id}><div className="history-icon"><CheckCircle2 size={17}/></div><div><strong>{s.displayName || 'Player'} · {s.workoutType}</strong><small>{s.completedAt?.toDate ? s.completedAt.toDate().toLocaleDateString() : 'Recently completed'}</small></div><b>+{s.xpEarned || 0} XP</b></div>) : <p className="muted">Your completed workouts will appear here.</p>}</section>
  </>;
}
function Stat({ icon, label, value }) { return <div className="stat-card"><div className="stat-icon">{icon}</div><div className="stat-label">{label}</div><div className="stat-value">{value}</div></div>; }

function WorkoutScreen({ workoutType, logs, editSet, pb, setPb, finishWorkout, busy, onBack }) {
  const [confirm, setConfirm] = useState(false);
  const filledExercises = logs.filter(l => l.sets.every(s => s.weight.trim() && s.reps.trim())).length;
  return <section className="workout-page"><button className="back-button" onClick={onBack}><ArrowLeft size={17}/> BACK TO HOME</button><div className="section-heading"><div><p className="eyebrow">SESSION IN PROGRESS</p><h1>{workoutType} Day</h1><p className="muted">Log your weight and reps for each of the 3 sets.</p></div><span className="tag">{filledExercises}/6 DONE</span></div><div className="alert info"><Activity size={17}/> Use controlled reps and stop if your form breaks. Don't force unsafe reps to finish a set.</div><label className="pb-check"><input type="checkbox" checked={pb} onChange={e => setPb(e.target.checked)}/><span><b>New personal best</b><small>Mark this if you beat a previous exercise record. +50 XP once per session.</small></span></label><div className="exercise-list">{logs.map((log,i)=><article className="exercise-card panel" key={log.name}><div className="exercise-heading"><span className="exercise-number">{String(i+1).padStart(2,'0')}</span><div><h3>{log.name}</h3><small>3 planned sets</small></div></div><div className="set-header"><span>SET</span><span>WEIGHT (KG)</span><span>REPS</span></div>{log.sets.map((set,j)=><div className="set-row" key={j}><span className="set-number">{j+1}</span><input aria-label={`${log.name} set ${j+1} weight in kg`} inputMode="decimal" value={set.weight} onChange={e => editSet(i,j,'weight',e.target.value)} placeholder="0"/><input aria-label={`${log.name} set ${j+1} reps`} inputMode="numeric" value={set.reps} onChange={e => editSet(i,j,'reps',e.target.value)} placeholder="0"/></div>)}</article>)}</div><div className="finish-bar"><div><small>BASE REWARD</small><strong>+100 XP</strong></div><button className="primary" onClick={() => setConfirm(true)} disabled={busy || !logs.some(l=>l.sets.some(s=>s.weight.trim() && s.reps.trim()))}>{busy ? 'SAVING…' : 'COMPLETE WORKOUT'} <CheckCircle2 size={17}/></button></div>{confirm && <div className="modal-backdrop"><div className="modal panel"><h2>Finish this workout?</h2><p className="muted">You'll earn +100 XP, +25 XP if all six exercises have all sets logged, +50 XP if you marked a new personal best, and +100 XP when you reach your fourth workout for the week.</p><div className="modal-actions"><button className="secondary" onClick={() => setConfirm(false)}>KEEP LOGGING</button><button className="primary" onClick={() => { setConfirm(false); finishWorkout(); }}>CONFIRM</button></div></div></div>}</section>;
}

function Leaderboard({ members, uid, onBack }) { return <section className="workout-page"><button className="back-button" onClick={onBack}><ArrowLeft size={17}/> HOME</button><div className="section-heading"><div><p className="eyebrow">ROOM RANKINGS</p><h1>Leaderboard</h1><p className="muted">Updates live as players complete workouts.</p></div><Trophy className="heading-icon" size={30}/></div>{members.length ? members.map((p,i)=><div className="leader-row panel" key={p.uid}><div className={`leader-place ${i===0?'first':''}`}>{i+1}</div><div className="player-avatar">{(p.displayName||'P').slice(0,1).toUpperCase()}</div><div className="player-name"><b>{p.displayName || 'Player'} {p.uid===uid && <em>YOU</em>}</b><small>{rankFor(p.xp||0)} · LEVEL {levelFor(p.xp||0)} · {p.workouts||0} workouts</small></div><div className="leader-xp">{(p.xp||0).toLocaleString()}<small>XP</small></div></div>) : <p className="muted">No players found in this room yet.</p>}<p className="tiny muted">Rankings are sorted by total XP. Your own workout history remains tied to your account.</p></section>; }
function StatsScreen({ me, history, onBack }) { return <section className="workout-page"><button className="back-button" onClick={onBack}><ArrowLeft size={17}/> HOME</button><div className="section-heading"><div><p className="eyebrow">PLAYER RECORD</p><h1>Stats & history</h1></div><Award className="heading-icon" size={30}/></div><section className="stat-grid"><Stat icon={<Zap/>} label="TOTAL XP" value={(me?.xp||0).toLocaleString()}/><Stat icon={<CalendarCheck/>} label="WORKOUTS" value={me?.workouts||0}/><Stat icon={<Trophy/>} label="PERSONAL BESTS" value={me?.personalBests||0}/><Stat icon={<Users/>} label="WEEKLY TARGET" value={`${me?.weekKey===weekKey()?(me?.weeklyWorkouts||0):0}/4`}/></section><section className="panel recent-panel"><h2>Room session history</h2>{history.length ? history.map(s=><div className="history-row" key={s.id}><div className="history-icon"><CheckCircle2 size={17}/></div><div><strong>{s.displayName || 'Player'} · {s.workoutType}</strong><small>{s.completedAt?.toDate ? s.completedAt.toDate().toLocaleString() : 'Recently completed'}</small></div><b>+{s.xpEarned||0} XP</b></div>) : <p className="muted">No sessions logged yet.</p>}</section></section>; }

createRoot(document.getElementById('root')).render(<React.StrictMode><App/></React.StrictMode>);
