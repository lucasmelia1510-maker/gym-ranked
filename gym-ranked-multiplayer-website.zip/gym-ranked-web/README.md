# Gym Ranked — two-player multiplayer website

A responsive React + Vite website designed for phones, with Firebase Authentication and Cloud Firestore real-time listeners. It keeps the existing Push/Pull templates, rank tiers, levels, XP, personal-best flag, stats, and four-workout weekly target.

## Honest deployment status

**This package is source code only. It has not been deployed to Vercel and is not connected to a Firebase project.** You must create your Firebase project, add its web configuration as environment variables, deploy Firestore rules, and deploy the Vercel project before two people can use live multiplayer.

## Features in this starter

- Email/password registration and sign-in
- Player display name and private room code
- Live two-player leaderboard via Firestore snapshots
- Push and Pull workout templates (six exercises, three sets each)
- Weight/reps input for each set
- XP: +100 workout completion, +25 for logging all six exercises completely, +50 for marking a new PB (once per session), +100 weekly target bonus when the fourth workout is completed
- Rank thresholds: Iron 0–599, Bronze 600–1,499, Silver 1,500–2,699, Gold 2,700–4,199, Platinum 4,200–6,199, Diamond 6,200–8,699, Elite 8,700–11,999, Champion 12,000+
- Level increments every 100 total XP
- Recent session feed and stats screen

### Important game/data notes

- The app starts each new player at zero. It does not import stats from the ChatGPT conversation.
- The existing routine is preserved: Push = Incline Dumbbell Bench Press, Pec Deck, Shoulder Press, Lateral Raise Machine, Triceps Extensions, Triceps Pulldowns. Pull = T-Bar Row, Close-Grip Seated Row, Preacher Curls, alternate Hammer Curls/Bayesian Curls, Seated Shrugs, Seated Crunches.
- Weekly counts reset when the app sees a new Monday-based week key. The fourth workout gets the +100 bonus and the visible count stays at 4/4 until the next week.
- The PB control is a player-declared flag, not an automatic comparison engine yet. The app records set values, but automatic PB detection and detailed exercise-by-exercise PB records are future improvements.
- This is a starter. For a production release, move XP award calculation and room creation/joining to trusted Firebase Cloud Functions, add server-side validation, room capacity enforcement, and automated tests. The included Firestore rules are a baseline for a private two-player trial, not a full anti-cheat system.
- The app asks players to use controlled reps and stop if form breaks; “to failure” is not required.

## 1. Create Firebase project

1. Go to https://console.firebase.google.com/ and create a project.
2. Add a **Web app** in Project settings. You do not need Firebase Hosting if deploying on Vercel.
3. In **Authentication → Sign-in method**, enable **Email/Password**.
4. In **Firestore Database**, create a database.
5. Open **Firestore → Rules**, paste the contents of `firestore.rules`, and publish. Review the production notes above before sharing publicly.
6. Copy the Firebase web config values for API key, auth domain, project ID, storage bucket, messaging sender ID, and app ID.

## 2. Run locally (optional)

Install Node.js 20+ and Git, then in this folder:

```bash
npm install
cp .env.example .env.local
```

Fill `.env.local` with the Firebase web config values (no quotes required):

```dotenv
VITE_FIREBASE_API_KEY=...
VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=...
VITE_FIREBASE_APP_ID=...
```

Then run:

```bash
npm run dev
```

## 3. Deploy to Vercel

1. Create a GitHub repository and upload the files in this folder.
2. Sign in to https://vercel.com/ and choose **Add New → Project**; import the repository.
3. Framework preset: **Vite**. Build command: `npm run build`. Output directory: `dist`.
4. In Vercel Project → **Settings → Environment Variables**, add the six `VITE_FIREBASE_...` values from `.env.local` for Production (and Preview if desired).
5. Deploy. Vercel will give you a website URL. It is not live until this deployment succeeds.
6. In Firebase Authentication settings, add the Vercel domain under **Authorized domains** if it is not already present.
7. Open the deployed URL on both phones. Each player creates a separate account. Player 1 creates a room and shares the room code; Player 2 enters that code and joins.

## 4. Security before inviting a second player

The room code is intended to be shared only with your chosen opponent. Never share passwords or private Firebase service-account keys. Only client-safe Firebase web config belongs in Vercel `VITE_` variables. Never put service account credentials in frontend code. For a public release, use Cloud Functions to validate room capacity, session ownership, XP awards, and weekly bonus calculations; tighten rules and test them with the Firebase Emulator Suite.

## File structure

```text
src/main.jsx       React UI, auth flow, room flow, workouts, stats and live leaderboard
src/firebase.js    Firebase client initialization
src/style.css     Responsive neon-green UI
firestore.rules    Baseline Firestore security rules
.env.example       Required Vercel/local environment variable names
```
